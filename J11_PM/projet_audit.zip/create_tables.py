from app.database import engine, Base 
from app import models  # ← IMPORT OBLIGATOIRE : enregistre User/Item dans Base.metadata 
Base.metadata.create_all(engine) 
print("Tables créées.")
